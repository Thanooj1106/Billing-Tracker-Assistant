# TODO: Improve Frontend UI for Patient Billing App

## Tasks
- [x] Add Bootstrap CDN to all HTML templates for modern styling
- [x] Update index.html: Add navigation bar, style patient list with cards, make responsive
- [x] Update add_patient.html: Style the form with Bootstrap components
- [x] Update appointment.html: Style the form with Bootstrap components
- [x] Update billing.html: Style the form with Bootstrap components
- [x] Update history.html: Enhance the billing history table with better styling, add total amount calculation, make responsive
- [x] Test the updated UI by running the Flask app and checking each page
- [x] Add payment to appointment booking and store in billing history

## Progress
- [x] Plan approved by user
