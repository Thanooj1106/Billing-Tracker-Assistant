from flask import Flask, render_template, request, redirect, url_for
from models import db, Patient, Appointment, Bill

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

with app.app_context():
    # Drop all tables and recreate to apply model changes
    db.drop_all()
    db.create_all()
    db.session.commit()


@app.route("/")
def index():
    patients = Patient.query.all()
    return render_template("index.html", patients=patients)

@app.route("/add_patient", methods=["GET", "POST"])
def add_patient():
    if request.method == "POST":
        patient = Patient(
            name=request.form["name"],
            age=int(request.form["age"]),
            contact=request.form["contact"],
            doctor=request.form["doctor"]
        )
        db.session.add(patient)
        db.session.commit()
        return redirect(url_for("index"))
    return render_template("add_patient.html")

@app.route("/appointment/<int:patient_id>", methods=["GET", "POST"])
def appointment(patient_id):
    patient = Patient.query.get(patient_id)
    if not patient:
        return "Patient not found", 404
    doctor_fees = {
        "thanooj": 400,
        "mahe": 500,
        "ram": 600,
        "sai": 700
    }
    amount = doctor_fees.get(patient.doctor.lower(), 400)
    if request.method == "POST":
        appointment = Appointment(
            doctor=patient.doctor,
            date=request.form["date"],
            patient_id=patient_id
        )
        db.session.add(appointment)
        db.session.commit()
        # Create bill for the appointment with fixed amount based on doctor
        bill = Bill(
            amount=amount,
            status="Paid",
            appointment_id=appointment.id
        )
        db.session.add(bill)
        db.session.commit()
        return redirect(url_for("history"))
    return render_template("appointment.html", patient_id=patient_id, amount=amount)

@app.route("/billing/<int:appointment_id>", methods=["GET", "POST"])
def billing(appointment_id):
    if request.method == "POST":
        bill = Bill(
            amount=request.form["amount"],
            status=request.form["status"],
            appointment_id=appointment_id
        )
        db.session.add(bill)
        db.session.commit()
        return redirect(url_for("history"))
    return render_template("billing.html", appointment_id=appointment_id)

@app.route("/history")
def history():
    bills = Bill.query.all()
    return render_template("history.html", bills=bills)

if __name__ == "__main__":
    app.run(debug=True)
